"""pc28.help 站点适配器：只解析开奖时间与历史开奖，不出预测票。

时钟：/api/kj.json 顶层 countdown 为距下期秒数，data[0] 为最新开奖，待开期号 = 最新期号 + 1。
历史：同一接口按 {limit} 取最近 N 期，号码写法兼容 "9+5+9" 与 "9+5+9=23"。
"""

from __future__ import annotations

from pc28.datafeeds.adapters.base import (
    AdapterContext,
    ClockReading,
    DrawDraft,
    VoteDraft,
    adapter,
)
from pc28.datafeeds.adapters.common import load_json


def _seconds(raw) -> int | None:
    parts = str(raw or "").split(":")
    if not 2 <= len(parts) <= 3 or not all(part.isdigit() for part in parts):
        return None
    total = 0
    for part in parts:
        total = total * 60 + int(part)
    return total


def _draw(raw) -> tuple[str, int] | None:
    text = str(raw or "")
    left, _, right = text.partition("=")
    numbers = [part.strip() for part in left.split("+")]
    if len(numbers) != 3 or not all(part.isdigit() for part in numbers):
        return None
    try:
        total = int(right)
    except (TypeError, ValueError):
        total = sum(int(part) for part in numbers)
    return "+".join(numbers), total


@adapter("ph_clock", emits=(), semantics=("info_only",))
def parse_clock(ctx: AdapterContext, payload: bytes) -> list[ClockReading]:
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list) or not rows:
        raise ValueError("data 为空")
    last = rows[0]
    if not isinstance(last, dict) or not str(last.get("nbr") or "").isdigit():
        raise ValueError("首条缺少期号")
    parsed = _draw(last.get("number"))
    if parsed is None:
        raise ValueError(f"开奖号码非法：{last.get('number')!r}")
    numbers, total = parsed
    return [ClockReading(
        issue=str(int(last["nbr"]) + 1),
        countdown=_seconds(document.get("countdown")),
        last_issue=str(last["nbr"]),
        numbers=numbers,
        total=total,
        time=f"{last.get('date') or ''} {last.get('time') or ''}".strip(),
    )]


@adapter("ph_history", emits=(), semantics=("info_only",))
def parse_history(ctx: AdapterContext, payload: bytes) -> list[DrawDraft]:
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list):
        raise ValueError("data 非数组")
    out: list[DrawDraft] = []
    for row in rows[:100]:
        if not isinstance(row, dict) or not row.get("nbr"):
            continue
        parsed = _draw(row.get("number"))
        if parsed is None:
            continue
        numbers, total = parsed
        out.append(DrawDraft(issue=str(row["nbr"]), numbers=numbers, total=total,
                             time=f"{row.get('date') or ''} {row.get('time') or ''}".strip()))
    if not out:
        raise ValueError("没有可用开奖行")
    return out


@adapter("ph_hold", emits=(), semantics=("info_only",))
def parse_hold(ctx: AdapterContext, payload: bytes) -> list[VoteDraft]:
    """占位源：满足“每站至少一条预测源”的校验，不产票、不会被计划抓取。"""
    return []


__all__ = ["parse_clock", "parse_history", "parse_hold"]
