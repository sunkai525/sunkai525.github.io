"""pc2868 站点适配器：只解析时钟与历史开奖，不出预测票。

时钟：/api.php?act=status 直接给待开期号 next_expect，倒计时 = next_open_time - server_time。
历史：/api.php?act=history 返回 data[]，最新在前，opencode 形如 "0+3+7"，opentime 为北京时间。
"""

from __future__ import annotations

from pc28.datafeeds.adapters.base import (
    AdapterContext,
    ClockReading,
    DrawDraft,
    VoteDraft,
    adapter,
)
from pc28.datafeeds.adapters.common import load_json


def _draw(raw) -> tuple[str, int] | None:
    parts = [part.strip() for part in str(raw or "").split("+")]
    if len(parts) != 3 or not all(part.isdigit() and int(part) <= 9 for part in parts):
        return None
    return "+".join(parts), sum(int(part) for part in parts)


def _countdown(document) -> int | None:
    try:
        return int(document["next_open_time"]) - int(document["server_time"])
    except (KeyError, TypeError, ValueError):
        return None


@adapter("pc2868_clock", emits=(), semantics=("info_only",))
def parse_clock(ctx: AdapterContext, payload: bytes) -> list[ClockReading]:
    document = load_json(payload)
    if not isinstance(document, dict):
        raise ValueError("状态不是对象")
    issue = str(document.get("next_expect") or "")
    last_issue = str(document.get("last_expect") or "")
    if not issue.isdigit() or not last_issue.isdigit():
        raise ValueError("期号缺失或非数字")
    parsed = _draw(document.get("last_opencode"))
    if parsed is None:
        raise ValueError(f"上期开奖号码非法：{document.get('last_opencode')!r}")
    numbers, total = parsed
    return [ClockReading(
        issue=issue,
        countdown=_countdown(document),
        last_issue=last_issue,
        numbers=numbers,
        total=total,
    )]


@adapter("pc2868_history", emits=(), semantics=("info_only",))
def parse_history(ctx: AdapterContext, payload: bytes) -> list[DrawDraft]:
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list):
        raise ValueError("data 非数组")
    out: list[DrawDraft] = []
    for row in rows[:100]:
        if not isinstance(row, dict):
            continue
        issue = str(row.get("expect") or "")
        if not issue.isdigit():
            continue
        parsed = _draw(row.get("opencode"))
        if parsed is None:
            continue
        numbers, total = parsed
        out.append(DrawDraft(issue=issue, numbers=numbers, total=total,
                             time=str(row.get("opentime") or "")))
    if not out:
        raise ValueError("没有可用开奖行")
    return out


@adapter("pc2868_hold", emits=(), semantics=("info_only",))
def parse_hold(ctx: AdapterContext, payload: bytes) -> list[VoteDraft]:
    """占位源：满足“每站至少一条预测源”的校验，不产票、不会被计划抓取。"""
    return []


__all__ = ["parse_clock", "parse_history", "parse_hold"]
