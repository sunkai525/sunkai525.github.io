"""yu28 站点适配器（配置同目录）。

四维预测：data[] 最新在前，首条为待开期，票值取 predict，权重按 hit 历史统计。
算法大厅：第一批 dt.json 取 id，第二批 sf.json 取 predict/predictNbr，权重取 hit100。
"""

from __future__ import annotations

from pc28.datafeeds.adapters.base import (
    AdapterContext,
    AlgorithmDetailDraft,
    AlgorithmDraft,
    AlgorithmRecordDraft,
    ClockReading,
    DrawDraft,
    VoteDraft,
    adapter,
)
from pc28.datafeeds.adapters.common import (
    hit_rate,
    load_json,
    normalize_combo,
    normalize_pair,
    rate,
)
from pc28.games.canada28.rules import diag


def _value(source, predict):
    if predict is None:
        return None
    text = str(predict).strip()
    if source.kind == "combo":
        if source.semantics == "combo_diag":
            combo = normalize_combo(text)
            return diag(combo) if combo else None
        return text
    if source.kind == "pair":
        return normalize_pair(text)
    if source.valid and text not in source.valid:
        return None
    return text


def _play_of(source) -> str:
    return {"pair": "sz", "combo": "kill"}.get(source.kind, source.kind)


@adapter("y28_rows", emits=("kill", "dx", "ds", "sz"),
         semantics=("kill_direct", "direct", "direct_pair"))
def parse_rows(ctx: AdapterContext, payload: bytes) -> list[VoteDraft]:
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list) or not rows:
        raise ValueError("data 为空")
    newest = rows[0]
    if not isinstance(newest, dict):
        raise ValueError("data[0] 不是对象")
    source = ctx.source
    if source is None:
        raise ValueError("缺少 source 配置")
    issue = newest.get("nbr")
    value = _value(source, newest.get("predict"))
    if issue is None or value is None:
        raise ValueError("首条预测字段不完整")
    weight = hit_rate(rows)
    if weight is None:
        weight = 0.5
    return [VoteDraft(play=_play_of(source), value=value, weight=weight, issue=str(issue))]


@adapter("y28_hall", emits=("kill", "dx", "ds", "sz"),
         semantics=("kill_direct", "direct", "direct_pair", "combo_diag"))
def parse_hall(ctx: AdapterContext, payload: bytes) -> list[VoteDraft]:
    document = load_json(payload)
    if not isinstance(document, dict):
        raise ValueError("详情不是对象")
    source = ctx.source
    if source is None:
        raise ValueError("缺少 source 配置")
    issue = document.get("predictNbr")
    value = _value(source, document.get("predict"))
    if issue is None or value is None:
        return []
    weight = rate(document.get("hit100")) or rate(document.get("hit20")) or 0.5
    return [VoteDraft(play=_play_of(source), value=value, weight=weight, issue=str(issue))]


@adapter("y28_hall_list", emits=(), semantics=("info_only",))
def parse_hall_list(ctx: AdapterContext, payload: bytes) -> list[AlgorithmDraft]:
    """解析大厅列表（dt.json），只做目录展示，不产票。"""
    document = load_json(payload)
    items = document.get("items") if isinstance(document, dict) else None
    if not isinstance(items, list):
        raise ValueError("items 不是数组")
    out: list[AlgorithmDraft] = []
    for item in items:
        if not isinstance(item, dict) or item.get("id") is None:
            continue
        out.append(AlgorithmDraft(
            id=str(item["id"]),
            name=str(item.get("name") or ""),
            category=str(item.get("category") or ""),
            author=str(item.get("author") or ""),
            rate20=str(item.get("hit20") or ""),
            rate100=str(item.get("hit100") or ""),
            streak=_int(item.get("streak")),
            miss=_int(item.get("miss")),
            max_streak=_int(item.get("maxStreak")),
            max_miss=_int(item.get("maxMiss")),
        ))
    return out


@adapter("y28_hall_detail", emits=(), semantics=("info_only",))
def parse_hall_detail(ctx: AdapterContext,
                      payload: bytes) -> list[AlgorithmDetailDraft]:
    """解析大厅算法详情（sf.json），只做展示，不产票。"""
    document = load_json(payload)
    if not isinstance(document, dict):
        raise ValueError("详情不是对象")
    records: list[AlgorithmRecordDraft] = []
    for row in document.get("records") or []:
        if not isinstance(row, dict) or not row.get("nbr"):
            continue
        hit = row.get("hit")
        records.append(AlgorithmRecordDraft(
            issue=str(row["nbr"]),
            predict=str(row.get("predict") or ""),
            number=str(row.get("number") or ""),
            result=str(row.get("result") or ""),
            hit=hit if isinstance(hit, bool) else None,
            time=str(row.get("time") or ""),
        ))
    return [AlgorithmDetailDraft(
        kind="hall",
        name=str(document.get("name") or ""),
        author=str(document.get("author") or ""),
        category=str(document.get("category") or ""),
        rate20=str(document.get("hit20") or ""),
        rate100=str(document.get("hit100") or ""),
        streak=_int(document.get("streak")),
        miss=_int(document.get("miss")),
        max_streak=_int(document.get("maxStreak")),
        max_miss=_int(document.get("maxMiss")),
        predict=str(document.get("predict") or ""),
        issue=str(document.get("predictNbr") or ""),
        records=tuple(records),
    )]


@adapter("y28_ai_detail", emits=(), semantics=("info_only",))
def parse_ai_detail(ctx: AdapterContext,
                    payload: bytes) -> list[AlgorithmDetailDraft]:
    """解析站方固定预测详情（ai.json），只做展示，不产票。"""
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list) or not rows:
        raise ValueError("data 为空")
    newest = rows[0]
    if not isinstance(newest, dict):
        raise ValueError("data[0] 不是对象")
    source = ctx.source
    play = source.plays[0] if source is not None and source.plays else ""
    records: list[AlgorithmRecordDraft] = []
    for row in rows:
        if not isinstance(row, dict) or not row.get("nbr"):
            continue
        hit = row.get("hit")
        numbers = str(row.get("number") or "")
        total = str(row.get("num") or "")
        records.append(AlgorithmRecordDraft(
            issue=str(row["nbr"]),
            predict=str(row.get("predict") or ""),
            number=f"{numbers} = {total}" if numbers and total else numbers,
            result=str(row.get("result") or ""),
            hit=hit if isinstance(hit, bool) else None,
        ))
    return [AlgorithmDetailDraft(
        kind="fixed",
        name=ctx.label or (source.id if source is not None else ""),
        author="官方",
        play=play,
        predict=str(newest.get("predict") or ""),
        issue=str(newest.get("nbr") or ""),
        records=tuple(records),
    )]


def _int(raw) -> int:
    try:
        return int(raw)
    except (TypeError, ValueError):
        return 0


def _seconds(raw) -> int | None:
    parts = str(raw or "").split(":")
    if not 2 <= len(parts) <= 3 or not all(part.isdigit() for part in parts):
        return None
    total = 0
    for part in parts:
        total = total * 60 + int(part)
    return total


def _numbers(raw) -> tuple[str, str] | None:
    text = str(raw or "")
    left, _, right = text.partition("=")
    numbers = [part.strip() for part in left.split("+")]
    if len(numbers) != 3 or not all(part.isdigit() for part in numbers):
        return None
    return "+".join(numbers), right


@adapter("y28_clock", emits=(), semantics=("info_only",))
def parse_clock(ctx: AdapterContext, payload: bytes) -> list[ClockReading]:
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list) or not rows:
        raise ValueError("data 为空")
    last = rows[0]
    if not isinstance(last, dict) or not last.get("nbr"):
        raise ValueError("首条缺少期号")
    parsed = _numbers(last.get("number"))
    if parsed is None:
        raise ValueError(f"开奖号码非法：{last.get('number')!r}")
    numbers, right = parsed
    try:
        total = int(right)
    except (TypeError, ValueError):
        total = sum(int(part) for part in numbers.split("+"))
    return [ClockReading(
        issue=str(int(last["nbr"]) + 1),
        countdown=_seconds(document.get("countdown")),
        last_issue=str(last["nbr"]),
        numbers=numbers,
        total=total,
        time=str(last.get("time") or ""),
    )]


@adapter("y28_history", emits=(), semantics=("info_only",))
def parse_history(ctx: AdapterContext, payload: bytes) -> list[DrawDraft]:
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list):
        raise ValueError("data 非数组")
    out: list[DrawDraft] = []
    for row in rows:
        if not isinstance(row, dict) or not row.get("nbr"):
            continue
        parsed = _numbers(row.get("number"))
        if parsed is None:
            continue
        numbers, right = parsed
        try:
            total = int(right)
        except (TypeError, ValueError):
            total = sum(int(part) for part in numbers.split("+"))
        out.append(DrawDraft(issue=str(row["nbr"]), numbers=numbers, total=total,
                             time=str(row.get("time") or "")))
    if not out:
        raise ValueError("没有可用开奖行")
    return out


@adapter("y28_qh", emits=(), semantics=("info_only",))
def parse_draw_by_issue(ctx: AdapterContext, payload: bytes) -> list[DrawDraft]:
    """按期号查单期开奖（/api/qh.json），data[0] 即该期开奖。"""
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list) or not rows:
        raise ValueError("data 为空")
    row = rows[0]
    if not isinstance(row, dict) or not row.get("nbr"):
        raise ValueError("缺少期号")
    parsed = _numbers(row.get("number"))
    if parsed is None:
        raise ValueError(f"开奖号码非法：{row.get('number')!r}")
    numbers, right = parsed
    try:
        total = int(right)
    except (TypeError, ValueError):
        total = sum(int(part) for part in numbers.split("+"))
    return [DrawDraft(issue=str(row["nbr"]), numbers=numbers, total=total,
                      time=str(row.get("time") or ""))]


__all__ = ["parse_rows", "parse_hall", "parse_hall_list", "parse_hall_detail",
           "parse_ai_detail", "parse_clock", "parse_history", "parse_draw_by_issue"]
