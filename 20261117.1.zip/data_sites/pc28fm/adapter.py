"""pc28fm 站点适配器（配置同目录）。

开奖： kj.json 里 data[] 最新在前，countdown 为 mm:ss；待开期号 = 最新期号 + 1。
预测： ds/dx/sz/sha.json 里 data[0] 是待开期，票值取 predict，权重按 hit 统计。
大厅： dt.json 的列表在 data[]（不是 items），命中率是「17/20」字符串；
       sf.json 的命中率在 stats 对象里且为纯数字，需拼成「82/100」。
"""

from __future__ import annotations

from pc28.datafeeds.adapters.base import (
    AdapterContext,
    AlgorithmDetailDraft,
    AlgorithmDraft,
    AlgorithmRecordDraft,
    ClockReading,
    DrawDraft,
    VoteDraft,
    adapter,
)
from pc28.datafeeds.adapters.common import (
    hit_rate,
    load_json,
    normalize_combo,
    normalize_pair,
)
from pc28.games.canada28.rules import diag


def _int(raw) -> int:
    try:
        return int(raw)
    except (TypeError, ValueError):
        return 0


def _ratio(hits, total) -> str:
    try:
        return f"{int(hits)}/{int(total)}"
    except (TypeError, ValueError):
        return ""


def _value(source, predict):
    """把站点预测值转成投票值；非法返回 None。"""
    if predict is None:
        return None
    text = str(predict).strip()
    if not text:
        return None
    if source.kind == "combo":
        if source.semantics == "combo_diag":
            combo = normalize_combo(text)
            return diag(combo) if combo else None
        return text
    if source.kind == "pair":
        return normalize_pair(text)
    if source.valid and text not in source.valid:
        return None
    return text


def _play_of(source) -> str:
    return {"pair": "sz", "combo": "kill"}.get(source.kind, source.kind)


@adapter("fm_rows", emits=("kill", "dx", "ds", "sz"),
         semantics=("kill_direct", "direct", "direct_pair"))
def parse_rows(ctx: AdapterContext, payload: bytes) -> list[VoteDraft]:
    """解析四维预测：首条即待开期；无真实预测时返回空列表。"""
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list):
        raise ValueError("data 不是数组")
    if not rows:
        return []
    newest = rows[0]
    if not isinstance(newest, dict):
        raise ValueError("data[0] 不是对象")
    source = ctx.source
    if source is None:
        raise ValueError("缺少 source 配置")
    issue = newest.get("nbr")
    value = _value(source, newest.get("predict"))
    if issue is None or value is None:
        return []
    weight = hit_rate(rows)
    return [VoteDraft(play=_play_of(source), value=value,
                      weight=0.5 if weight is None else weight,
                      issue=str(issue))]


@adapter("fm_hall_list", emits=(), semantics=("info_only",))
def parse_hall_list(ctx: AdapterContext, payload: bytes) -> list[AlgorithmDraft]:
    """解析大厅列表（dt.json），只做目录展示，不产票。"""
    document = load_json(payload)
    items = document.get("data") if isinstance(document, dict) else None
    if not isinstance(items, list):
        raise ValueError("data 不是数组")
    out: list[AlgorithmDraft] = []
    for item in items:
        if not isinstance(item, dict) or item.get("id") is None:
            continue
        out.append(AlgorithmDraft(
            id=str(item["id"]),
            name=str(item.get("name") or ""),
            category=str(item.get("category") or ""),
            author=str(item.get("author") or ""),
            rate20=str(item.get("hit20") or ""),
            rate100=str(item.get("hit100") or ""),
            streak=_int(item.get("streak")),
            miss=_int(item.get("miss")),
            max_streak=_int(item.get("max_streak")),
            max_miss=_int(item.get("max_miss")),
        ))
    return out


@adapter("fm_hall_detail", emits=(), semantics=("info_only",))
def parse_hall_detail(ctx: AdapterContext,
                      payload: bytes) -> list[AlgorithmDetailDraft]:
    """解析大厅算法详情（sf.json），只做展示，不产票。"""
    document = load_json(payload)
    if not isinstance(document, dict):
        raise ValueError("详情不是对象")
    stats = document.get("stats") if isinstance(document.get("stats"), dict) else {}
    records: list[AlgorithmRecordDraft] = []
    for row in document.get("records") or []:
        if not isinstance(row, dict) or not row.get("nbr"):
            continue
        hit = row.get("hit")
        records.append(AlgorithmRecordDraft(
            issue=str(row["nbr"]),
            predict=str(row.get("predict") or ""),
            number=str(row.get("number") or ""),
            result=str(row.get("result") or ""),
            hit=hit if isinstance(hit, bool) else None,
            time=str(row.get("time") or ""),
        ))
    return [AlgorithmDetailDraft(
        kind="hall",
        name=str(document.get("name") or ""),
        author=str(document.get("author") or ""),
        category=str(document.get("category") or ""),
        rate20=_ratio(stats.get("hit20"), stats.get("total20")),
        rate100=_ratio(stats.get("hit100"), stats.get("total100")),
        streak=_int(stats.get("streak")),
        miss=_int(stats.get("miss")),
        max_streak=_int(stats.get("max_streak")),
        max_miss=_int(stats.get("max_miss")),
        predict=str(document.get("predict") or ""),
        issue=str(document.get("predictNbr") or ""),
        records=tuple(records),
    )]


def _seconds(raw) -> int | None:
    parts = str(raw or "").split(":")
    if not 2 <= len(parts) <= 3 or not all(part.isdigit() for part in parts):
        return None
    total = 0
    for part in parts:
        total = total * 60 + int(part)
    return total


def _numbers(raw) -> tuple[str, str] | None:
    text = str(raw or "")
    left, _, right = text.partition("=")
    numbers = [part.strip() for part in left.split("+")]
    if len(numbers) != 3 or not all(part.isdigit() for part in numbers):
        return None
    return "+".join(numbers), right


@adapter("fm_clock", emits=(), semantics=("info_only",))
def parse_clock(ctx: AdapterContext, payload: bytes) -> list[ClockReading]:
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list) or not rows:
        raise ValueError("data 为空")
    last = rows[0]
    if not isinstance(last, dict) or not last.get("nbr"):
        raise ValueError("首条缺少期号")
    parsed = _numbers(last.get("number"))
    if parsed is None:
        raise ValueError(f"开奖号码非法：{last.get('number')!r}")
    numbers, right = parsed
    try:
        total = int(right)
    except (TypeError, ValueError):
        total = sum(int(part) for part in numbers.split("+"))
    return [ClockReading(
        issue=str(int(last["nbr"]) + 1),
        countdown=_seconds(document.get("countdown")),
        last_issue=str(last["nbr"]),
        numbers=numbers,
        total=total,
        time=str(last.get("time") or ""),
    )]


@adapter("fm_history", emits=(), semantics=("info_only",))
def parse_history(ctx: AdapterContext, payload: bytes) -> list[DrawDraft]:
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list):
        raise ValueError("data 不是数组")
    out: list[DrawDraft] = []
    for row in rows:
        if not isinstance(row, dict) or not row.get("nbr"):
            continue
        parsed = _numbers(row.get("number"))
        if parsed is None:
            continue
        numbers, right = parsed
        try:
            total = int(right)
        except (TypeError, ValueError):
            total = sum(int(part) for part in numbers.split("+"))
        out.append(DrawDraft(issue=str(row["nbr"]), numbers=numbers, total=total,
                             time=str(row.get("time") or "")))
    if not out:
        raise ValueError("没有可用开奖行")
    return out


@adapter("fm_qh", emits=(), semantics=("info_only",))
def parse_draw_by_issue(ctx: AdapterContext, payload: bytes) -> list[DrawDraft]:
    """按期号查单期开奖（/api/qh.json），data[0] 即该期开奖。"""
    document = load_json(payload)
    rows = document.get("data") if isinstance(document, dict) else None
    if not isinstance(rows, list) or not rows:
        raise ValueError("data 为空")
    row = rows[0]
    if not isinstance(row, dict) or not row.get("nbr"):
        raise ValueError("缺少期号")
    parsed = _numbers(row.get("number"))
    if parsed is None:
        raise ValueError(f"开奖号码非法：{row.get('number')!r}")
    numbers, right = parsed
    try:
        total = int(right)
    except (TypeError, ValueError):
        total = sum(int(part) for part in numbers.split("+"))
    return [DrawDraft(issue=str(row["nbr"]), numbers=numbers, total=total,
                      time=str(row.get("time") or ""))]


__all__ = ["parse_rows", "parse_hall_list", "parse_hall_detail",
           "parse_clock", "parse_history", "parse_draw_by_issue"]
